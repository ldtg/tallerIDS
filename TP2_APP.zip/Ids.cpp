#include "Ids.h"
#include "Lock.h"
#include <string>
#include <vector>
Ids::Ids(std::string archivo, EnsambladorMonitor &ensambladorMonitor, Detector
&dtk)
    : ensambladorMonitor(ensambladorMonitor),
      sniffer(archivo), detector(dtk) {}

void Ids::run() {
  Paquete paqueteNuevo;
  bool nuevoCompleto = false;
  while (!sniffer.termino()) {
    while (!sniffer.termino() && !nuevoCompleto) {
      Paquete paquete = sniffer.sniff();
      if (paquete.estaCompleto()) {
        paqueteNuevo = paquete;
        nuevoCompleto = true;
      } else {
        if (!paquete.estaVacio())
          paqueteNuevo = ensambladorMonitor.agregar(paquete);
        if (paqueteNuevo.estaCompleto()) {
          nuevoCompleto = true;
        }
      }
    }
    nuevoCompleto = false;
    //AnalizarPaquetenuevo
    if (!sniffer.termino()) {
      detector.aplicar(paqueteNuevo);
    }
  }
}

