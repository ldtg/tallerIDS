//
// Created by tg on 07/04/17.
//

#include <mutex>
#include "Ensamblador.h"
#include "Lock.h"

Paquete Ensamblador::agregar(Paquete paqueteNuevo) {
  if (paquetes.find(paqueteNuevo.getId()) != paquetes.end()) {
    Paquete paqueteActual = paquetes.at(paqueteNuevo.getId());
    paqueteActual.ensamblar(paqueteNuevo);
    paquetes[paqueteNuevo.getId()] = paqueteActual;
    return paqueteActual;
  } else {
    paquetes.emplace(paqueteNuevo.getId(), paqueteNuevo);
    return paqueteNuevo;
  }
}

Ensamblador::~Ensamblador() {
  paquetes.clear();
}
Ensamblador::Ensamblador() {
}
